<?php
require 'connection.php';
session_start();

if (!isset($_SESSION['opsname'])) {
    header("Location: index.html");
}else{
  $filter = $_SESSION['opsname'];
  $query=mysqli_query($conn,"SELECT * FROM `users` WHERE `User_ID`='$filter'")or die(mysqli_error());
  $row1=mysqli_fetch_array($query);
}
?>

<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Safaricom’s Enterprise Business Unit - Operations Staff Homepage</title>

  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Baloo+Chettan|Dosis:400,600,700|Poppins:400,600,700&display=swap" rel="stylesheet" />
  <!-- Custom styles -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
</head>

        <style type="text/css">
        
          table{
    align-items: center;
  }

   th, tr, td{
    padding: 10px 10px;
    border: solid red 1px;
  }
    </style>

<script type="text/javascript">
function printData1()
{
   var divToPrint=document.getElementById("printTable1");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData1();
})  
</script>

<script type="text/javascript">
function printData2()
{
   var divToPrint=document.getElementById("printTable2");
   newWin= window.open("");
   newWin.document.write(divToPrint.outerHTML);
   newWin.print();
   newWin.close();
}

$('button').on('click',function(){
printData2();
})  
</script>

<body>
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <div class="header_nav">
          <a class="navbar-brand brand_desktop" href="operations_staff.php">
            <img src="images/safcom_logo.png" alt="" />
          </a>
          <div class="main_nav">
            <div class="top_nav">
              <ul class=" ">
                <li class="">
                  <a class="" href="">
                    <img src="images/telephone.png" alt="" />
                    <span> +254 722 254315</span>
                  </a>
                </li>
                <li class="">
                  <a class="" href="">
                    <img src="images/mail.png" alt="" />
                    <span>safaricom_ebu@gmail.com</span>
                  </a>
                </li>
                <li class="">
                  <a class="" href="">
                    <img src="images/location.png" alt="" />
                    <span>Nairobi, Kenya.</span>
                  </a>
                </li>
              </ul>
            </div>
            <div class="bottom_nav">
              <nav class="navbar navbar-expand-lg custom_nav-container">
                <a class="navbar-brand brand_mobile" href="operations_staff.php">
                  <img src="images/safcom_logo.png" alt="" />
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                  <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <div class="d-flex ml-auto flex-column flex-lg-row align-items-center">
                    <ul class="navbar-nav  ">
                      <li class="nav-item active">
                        <a class="nav-link" href="operations_staff.php">Home <span class="sr-only">(current)</span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#records"> View Records </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="#module"> My Module </a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </header>
    <!-- end header section -->
    <!-- slider section -->
    <section class=" slider_section position-relative">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-10 mx-auto">
            <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
              <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active">01</li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1">02</li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2">03</li>
              </ol>
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <div class="box">
                    <div class="detail-box">
                      <h1>
                        Welcome <?php echo $row1['User_Type']; ?>,   <br />
                        <?php echo $row1['Fullname']; ?>!
                      </h1>
                      <hr />
                      <div class="btn-box">
                        <a href="#contact" class="btn-1">
                          Contact Us
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="carousel-item">
                  <div class="box">
                    <div class="detail-box">
                      <h1>
                        Welcome <?php echo $row1['User_Type']; ?>,   <br />
                        <?php echo $row1['Fullname']; ?>!
                      </h1>
                      <hr />
                      <div class="btn-box">
                        <a href="#module" class="btn-1">
                          My Module
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="carousel-item">
                  <div class="box">
                    <div class="detail-box">
                      <h1>
                        Welcome <?php echo $row1['User_Type']; ?>,   <br />
                        <?php echo $row1['Fullname']; ?>!
                      </h1>
                      <hr />
                      <div class="btn-box">
                        <a href="#records" class="btn-1">
                          View Records
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="sr-only">Previous</span>
              </a>
              <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="sr-only">Next</span>
              </a>
            </div>
          </div>
        </div>
      </div>

    </section>
    <!-- end slider section -->
  </div>

  <!-- gallery section -->

  <section class="class_section " id="gallery">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-10 col-lg-8 mx-auto">
          <div class="class_container">
            <div class="row">
              <div class="col-lg-9 col-md-10">
                <div class="heading_container">
                  <h2>
                    View Records
                  </h2>
                  <p>
                   1. List of Merchandise (ordered by demand)
                  </p>
                </div>
              </div>
            </div>
            <div class="class_box-container">
                                       <table id="printTable1">
<tr style="text-align: left;
  padding: 8px;">
<th style="text-align: left;
  padding: 8px;">Merchandise ID</th>
<th style="text-align: left;
  padding: 8px;">Name</th>
  <th style="text-align: left;
  padding: 8px;">Quantity</th>
 <th style="text-align: left;
  padding: 8px;">Price (in kshs.)</th>
    <th style="text-align: left;
  padding: 8px;">Image</th>
 <th style="text-align: left;
  padding: 8px;">Created On</th>
</tr>

<?php
$sql = "SELECT `Merchandise_ID`, `Name`, `Quantity`, `Selling_Price`, `Image`, `Supplier`, `Created_On` FROM `merchandise` ORDER BY `Quantity` DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo($row["Merchandise_ID"]); ?></td>
<td><?php echo($row["Name"]); ?> from <?php echo($row["Supplier"]); ?></td>
<td><?php echo($row["Quantity"]); ?></td>
<td><?php echo($row["Selling_Price"]); ?></td>
<td><img src="images/<?php echo($row["Image"]); ?>" title="<?php echo($row["Name"]); ?>" style="width: 200px;"></td>
<td><?php echo($row["Created_On"]); ?></td>
</tr>
<?php
}
} else { echo "No results"; }

?>

</table>
<br>
<br>
                  <button style="margin-top: 20px; margin-bottom: 20px;" class="btn btn-primary py-3 px-5" onclick="printData1()">
                    Generate Report
                  </button>
                  <br>
                  <br>
            </div>
          </div>
        </div>
                        <div class="col-md-10 col-lg-8 mx-auto">
          <div class="class_container">
            <div class="row">
              <div class="col-lg-9 col-md-10">
                <div class="heading_container">
                  <p>
                   2. List of Orders (ordered by demand)
                  </p>
                </div>
              </div>
            </div>
            <div class="class_box-container">
                                       <table id="printTable2">
<tr style="text-align: left;
  padding: 8px;">
<th style="text-align: left;
  padding: 8px;">Order ID</th>
<th style="text-align: left;
  padding: 8px;">Merchandise</th>
  <th style="text-align: left;
  padding: 8px;">Ordered By</th>
 <th style="text-align: left;
  padding: 8px;">Price (in kshs.)</th>
      <th style="text-align: left;
  padding: 8px;">Transport Type</th>
 <th style="text-align: left;
  padding: 8px;">Timeline</th>
   <th style="text-align: left;
  padding: 8px;">Status</th>
   <th style="text-align: left; padding: 8px;"></th>
</tr>

<?php
$sql = "SELECT `orders`.`Order_ID`, `orders`.`Sales_Staff_ID`, `orders`.`Operations_Staff_ID`, `orders`.`Merchandise_ID`, `orders`.`Ordered_At`, `orders`.`Ordered_Fulfilled_At`, `orders`.`Estimated_Arrival`, `orders`.`Payment_Type`, `orders`.`Transport_Type`, `orders`.`Price`, `orders`.`Amount`, `orders`.`Status`, `users`.`Fullname`, `users`.`Phone_Number`, `users`.`Email_Address` FROM `orders` JOIN `users` ON `users`.`User_ID` = `orders`.`Sales_Staff_ID` WHERE `orders`.`Operations_Staff_ID` = '$filter' OR `orders`.`Operations_Staff_ID` = '' ORDER BY `orders`.`Amount` DESC";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
?>
<tr>
<td><?php echo($row["Order_ID"]); ?></td>
<td><?php echo($row["Amount"]); ?> <?php echo($row["Merchandise_ID"]); ?></td>
<td><?php echo($row["Fullname"]); ?> reach out on <?php echo($row["Phone_Number"]); ?> or <?php echo($row["Email_Address"]); ?></td>
<td><?php echo($row["Price"]); ?></td>
<td><?php echo($row["Transport_Type"]); ?></td>
<?php
if($row["Status"] == 'Pending'){
?>
<td>Ordered on <?php echo($row["Ordered_At"]); ?> to be fulfilled on <?php echo($row["Estimated_Arrival"]); ?></td>
<?php
}else{
?>
<td>Ordered on <?php echo($row["Ordered_At"]); ?> fulfilled on <?php echo($row["Ordered_Fulfilled_At"]); ?></td>
<?php
}
?>
<td><?php echo($row["Status"]); ?></td>
<?php
if($row["Status"] == 'Pending'){
?>
<td><button class="btn btn-primary py-3 px-5" onclick="return confirm('Are you sure that you want to complete this order?')?window.location.href='main_functions.php?action=completeO&id=<?php echo($row["Order_ID"]); ?>&id1=<?php echo($row["Amount"]); ?>&id2=<?php echo($row["Merchandise_ID"]); ?>':true;" title='Complete Order'>Complete</button></td>
<?php
}else{
?>

<?php
}
?>
</tr>
<?php
}
} else { echo "No results"; }

?>

</table>
<br>
<br>
                  <button style="margin-top: 20px; margin-bottom: 20px;" class="btn btn-primary py-3 px-5" onclick="printData2()">
                    Generate Report
                  </button>
                  <br>
                  <br>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end gallery section -->

  <!-- info section -->
  <div class="info_section" id="module">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-10 ml-auto">
          <div class="row info_main-row">
            <div class="col-md-6 pr-0">

              <!-- start section -->

              <section class="contact_section">
                <br>
                <br>
                <h2>
                  My Module
                </h2>
                <form action="main_functions.php" method="POST">
                  <div>
                    <input type="text" placeholder="Fullname" required name="fname" value="<?php echo $row1['Fullname']; ?>" />
                    <input type="hidden" value="2" required name="mod">
                    <input type="hidden" value="<?php echo $filter; ?>" required name="uid">
                  </div>
                  <div>
                    <input type="text" placeholder="Phone Number" required name="phone" value="<?php echo $row1['Phone_Number']; ?>" />
                  </div>
                  <div>
                    <input type="email" placeholder="Email Address" name="email" value="<?php echo $row1['Email_Address']; ?>" required />
                  </div>
                  <div>
                    <input type="password" placeholder="Password" required name="password" />
                  </div>
                  <div>
                    <input type="password" placeholder="Confirm Password" required name="cpassword" />
                  </div>
<!--                   <div>
                    <input type="text" class="message-box" placeholder="Message" required />
                  </div> -->
                  <div class="d-flex ">
                    <button name="upu" type="submit">
                      UPDATE MY DETAILS
                    </button>
                  </div>
                </form>
              </section>

              <!-- end start section -->


            </div>
            <div class="col-md-6  px-0">
              <section class="contact_section">
                <form action="main_functions.php" method="POST" enctype="multipart/form-data">
                  <div>
                  <select required name="mid">
                                <option selected disabled value="0">Select A Merchandise</option>
                                  <?php
                                      $sql = "SELECT * FROM `merchandise`";
                                      $all_categories = mysqli_query($conn, $sql);
                                      while ($category = mysqli_fetch_array(
                                      $all_categories,MYSQLI_ASSOC)):;
                                  ?>
                                  <option value="<?php echo $category["Merchandise_ID"];?>"><?php echo $category["Name"];?> with <?php echo $category["Quantity"];?> in stock.</option>
                                  <?php
                                      endwhile;
                                  ?>
                  </select>
                  </div>
                  <div>
                    <input type="number" min="0" placeholder="Quantity" required name="quan" />
                  </div>
                  <div class="d-flex ">
                    <button name="uppM" type="submit">
                      ADD MERCHANDISE QUANTITY
                    </button>
                  </div>
                </form>
              </section>
            </div>
          </div>
                        <!-- footer section -->
              <section id="contact" class=" footer_section ">
                <div class="social_box">
                  <a href="#">
                    <img src="images/facebook.png" alt="">
                  </a>
                  <a href="#">
                    <img src="images/twitter.png" alt="">
                  </a>
                  <a href="#">
                    <img src="images/linkedin.png" alt="">
                  </a>
                  <a href="#">
                    <img src="images/instagram.png" alt="">
                  </a>
                  <a href="#">
                    <img src="images/youtube.png" alt="">
                  </a>
                </div>
                <p>
                  &copy; 2023 All Rights Reserved.
                </p>
              </section>
              <!-- footer section -->
        </div>
      </div>
    </div>
  </div>
  <!-- end info section -->

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>

  <script>
    function openNav() {
      document.getElementById("myNav").classList.toggle("menu_width");
      document.querySelector(".custom_menu-btn").classList.toggle("menu_btn-style");
    }
  </script>

  <!-- owl carousel script -->
  <script type="text/javascript">
    $(".owl-carousel").owlCarousel({
      loop: true,
      margin: 10,
      nav: true,
      navText: [],
      autoplay: true,
      autoplayHoverPause: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 2
        }
      }
    });


    $(".owl_carousel1").owlCarousel({
      loop: true,
      margin: 25,
      nav: true,
      navText: [],
      autoplay: true,
      autoplayHoverPause: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 2
        }
      }
    });
  </script>
  <!-- end owl carousel script -->


</body>

</html>