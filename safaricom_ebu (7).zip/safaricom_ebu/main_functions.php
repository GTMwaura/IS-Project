<?php 
 
require 'connection.php';

session_start();

//Register User
if (isset($_POST['regu'])) {
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $type = $_POST['type'];
 $gender = $_POST['gender'];
 $dob = $_POST['dob']; 
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];

$now = date('Y-m-d');
$dateTimestamp = strtotime($dob); 
$dateTimestamp1 = strtotime($now); 

if ($dateTimestamp > $dateTimestamp1){
echo "Date of Birth cannot be greater than the current date.";
}else{
 if ($password == $passwordconfirm) {
  $sql = "INSERT INTO `users`(`Fullname`, `Phone_Number`, `Email_Address`, `Gender`, `Date_of_Birth`, `Password`, `User_Type`) VALUES ('$fname','$phone','$email','$gender','$dob',md5('$password'),'$type')";
     mysqli_query($conn, $sql);
 if(!isset($_SESSION['adminname'])){
  header("Location: index.html?userregistration=success");
 }else{
  header("Location: admin.php?userregistration=success");
  }
}else{
  echo "Passwords do not match.";
 }
}
}

//Update User
if (isset($_POST['upu'])) {
 $uid = $_POST['uid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];
 $phone = $_POST['phone'];
 $mod = $_POST['mod'];

 if ($password == $passwordconfirm) {
  if ($mod == 1) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: admin.php?updateadministrator=success");
  }else if ($mod == 2) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: operations_staff.php?updateoperationsstaff=success");
  }else if ($mod == 3) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: sales_staff.php?updatesalesstaff=success");
  }else if ($mod == 4) {
  $sql = "UPDATE `users` SET `Fullname`='$fname',`Email_Address`='$email',`Phone_Number`='$phone',`Password`=md5('$password') WHERE `User_ID`='$uid'";
     mysqli_query($conn, $sql);
  header("Location: admin.php?updateauser=success");
  }
 }else{
  echo "Passwords do not match.";
 }
}

//Delete A User
if($_REQUEST['action'] == 'deleteU' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$sql = "DELETE FROM `users` WHERE `User_ID` = '$deleteItem'";
mysqli_query($conn, $sql); 
header("Location: admin.php?deleteuser=success");
}

//Approve A User
if($_REQUEST['action'] == 'approveU' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$sql = "UPDATE `users` SET `Status` = 'Active' WHERE `User_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: admin.php?activateuser=success");
}

//Add Merchandise
if (isset($_POST['addM'])) {
 $mname = $_POST['mname'];
 $sprice = $_POST['sprice'];
 $supplier = $_POST['supplier'];  
 $quan = $_POST['quan'];

$imagefile = $_FILES['image']['name'];

$valid_extensions = array("jpg","jpeg","png");

$extension = pathinfo($imagefile, PATHINFO_EXTENSION);

if(in_array(strtolower($extension),$valid_extensions) ) {

if(move_uploaded_file($_FILES['image']['tmp_name'], "images/".$imagefile)){

  $sql = "INSERT INTO `merchandise`(`Name`, `Quantity`, `Selling_Price`, `Image`, `Supplier`) VALUES ('$mname','$quan','$sprice','$imagefile','$supplier')";
     mysqli_query($conn, $sql);
  header("Location: admin.php?addmerchandise=success");
 }else{
  echo "There is an error with processing the image, directory not found.";
}
}else{
  echo "There is an error with processing image, kindly check the image format.";
}
}

//Update Merchandise Quantity
if (isset($_POST['uppM'])) {
 $mid = $_POST['mid']; 
 $quan = $_POST['quan'];

  $sql = "UPDATE `merchandise` SET `Quantity` = `Quantity` + '$quan' WHERE `Merchandise_ID` = '$mid'";
     mysqli_query($conn, $sql);
  header("Location: operations_staff.php?updatemerchandise=success");
 }

//Delete Merchandise
if($_REQUEST['action'] == 'deleteM' && !empty($_REQUEST['id'])){ 
$deleteItem = $_REQUEST['id'];
$sql = "DELETE FROM `merchandise` WHERE `Merchandise_ID` = '$deleteItem'";
mysqli_query($conn, $sql); 
$sql1 = "DELETE FROM `orders` WHERE `Merchandise_ID` = '$deleteItem'";
mysqli_query($conn, $sql1); 
header("Location: admin.php?deletemerchandise=success");
}

//Add an Order
if (isset($_POST['addorder'])) {
 $sid = $_SESSION['salsname'];
 $merch = explode(',', $_POST['mid']);
 $mid = $merch[0] . " from " . $merch[1];
 $price = $merch[2];
 $d = strtotime("+3 Days");
 $et =  date("Y-m-d h:i:sa", $d); 
 $amo = $_POST['amo'];
 $ptype = $_POST['ptype'];
 $ttype = $_POST['ttype1'] . " to " . $_POST['loc'];   


  $sql = "INSERT INTO `orders`(`Sales_Staff_ID`, `Merchandise_ID`, `Estimated_Arrival`, `Payment_Type`, `Transport_Type`, `Price`, `Amount`) VALUES ('$sid','$mid','$et','$ptype','$ttype','$price','$amo')";
     mysqli_query($conn, $sql);
  header("Location: sales_staff.php?addOrder=success");
 }

//Complete an Order
if($_REQUEST['action'] == 'completeO' && !empty($_REQUEST['id']) && !empty($_REQUEST['id1']) && !empty($_REQUEST['id2'])){ 
$updateItem = $_REQUEST['id'];
$quan = $_REQUEST['id1'];
$ex = explode($quan, $_REQUEST['id2']);
$ex1 = explode('from', $ex[0]);
$uid = $_SESSION['opsname'];
$merch = trim($ex1[0]);
$sql = "UPDATE `orders` SET `Status` = 'Completed', `Ordered_Fulfilled_At` = NOW(), `Operations_Staff_ID` = '$uid' WHERE `Order_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
$sql1 = "UPDATE `merchandise` SET `Quantity` = `Quantity` - '$quan' WHERE `Name` = '$merch'";
mysqli_query($conn, $sql1); 
var_dump($sql1);
header("Location: operations_staff.php?completeOrder=success");
}

//Cancel an Order
if($_REQUEST['action'] == 'cancelO' && !empty($_REQUEST['id'])){ 
$updateItem = $_REQUEST['id'];
$sql = "UPDATE `orders` SET `Status` = 'Cancelled' WHERE `Order_ID` = '$updateItem'";
mysqli_query($conn, $sql); 
header("Location: sales_staff.php?cancelOrder=success");
}

 ?>