<?php
require_once "connection.php";

session_start();


if(isset($_POST['login'])){

    $id = $_POST['email'];
    $password = $_POST['password'];   

        $sql = "SELECT * FROM `users` WHERE `Email_Address`='$id' AND `Status` = 'Active'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){
            $row = mysqli_fetch_assoc($query);

            $pass = $row['Password'];
            $type = $row['User_Type'];

if(md5($password) == $pass){

                if ($type == "Administrator") {
                $_SESSION['adminname'] = $row['User_ID'];
                header("Location: admin.php");
                }else if ($type == "Operations Staff") {
                $_SESSION['opsname'] = $row['User_ID'];           
                header("Location: operations_staff.php");
                }else if ($type == "Sales Staff") {
                $_SESSION['salsname'] = $row['User_ID'];             
                header("Location: sales_staff.php");
            }
            }else{
                echo "Incorrect Password.";
            }
        }else{
            echo "User Account not activated yet.";
        }
}
           
?>
